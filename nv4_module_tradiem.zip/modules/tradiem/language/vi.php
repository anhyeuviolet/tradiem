<?php
/**
 * @Author GaNguCay (gangucay@gmail.com)
 * @copyright Freeware
 * @createdate 11/08/2010
 */

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="Tr&#7847;n Th&#7871; Vinh (gangucay@gmail.com)";
$lang_translator['createdate'] ="18/07/2010, 15:22";
$lang_translator['copyright'] ="Freeware";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['main_title'] = "TKB gi�o vi�n"

?>